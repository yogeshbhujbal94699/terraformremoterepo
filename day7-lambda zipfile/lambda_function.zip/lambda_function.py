
def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Hello from Terraform Lambda!"
    }

# For creating zip file--
# In bash terminal type below command 
#  zip lambda.zip lambda_function.py
